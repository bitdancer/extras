A simple asyncio json REST server
---------------------------------

yada yada
